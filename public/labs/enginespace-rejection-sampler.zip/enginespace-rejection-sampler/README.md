# Keep or Re-plate

enginespace forge lab `rejection-sampler`. The commis plates a run of courses ahead of you, and you are the chef at the pass: keep a plate with probability min(1, p/q), and at the first one you send back, re-plate from the dishes the commis under-plates, (p − q)⁺. If every plate is kept you plate one more course yourself, and what goes out must be exactly what you would have plated alone. In the engine's words: speculative decoding's exact verifier, a rejection sampler.

Real Rust, on your machine, with no server. You edit one file, prove it with `cargo test`, build it to WebAssembly and drop the `.wasm` on the lab's page on the enginespace site (`/labs/rejection-sampler`). The page runs your module in your browser against the site's own checks and records the run on your device. Your code is never uploaded.

## What is in this folder

| Path | What |
|---|---|
| `rejection-sampler/src/verify.rs` | **Yours.** The only file marked `TODO(you)`. |
| `rejection-sampler/src/lib.rs` | The harness (DO NOT EDIT): the crate's own checks, and `ks_invoke`, the bridge the site drives. Reading it is allowed, and the header says which check catches which mistake. |
| `rejection-sampler/tests/` | The crate's tests, which run those checks. |
| `kit/` | kslab, the small crate that gives your module its ABI: no dependencies and no imports. |
| `rust-toolchain.toml`, `Cargo.lock` | The compiler the checks were written against (Rust 1.96.0, with the wasm32 target) and the lockfile. |
| `AGENTS.md`, `CLAUDE.md`, `.claude/` | Rules and a guard for a coding agent (below). |
| `NOTICE` | Whose code `kit/` and the guard are. |

## The loop

1. Read `rejection-sampler/src/verify.rs`, then the header of `rejection-sampler/src/lib.rs`.
2. `cargo test`, until every check is green. It starts red, because the file you edit holds `todo!()`.
3. `cargo build --release --target wasm32-unknown-unknown`
4. Drop `target/wasm32-unknown-unknown/release/rejection_sampler.wasm` on the lab's page.

The first time you run cargo here, rustup reads `rust-toolchain.toml` and fetches the compiler and the wasm32 target (`rustup toolchain install` does it by hand). No rustup yet? It is at <https://rustup.rs>. The archive's root is a Cargo workspace, so cargo writes `target/` here, one folder above the crate.

## The checks

| Check | Stage | Seeded | What it catches |
|---|---|---|---|
| `accept` | 1 | yes, new inputs on every run | A rule that keeps the wrong number of the coins: p > q taken as a yes or no with no coin, a comparison that includes the boundary (u <= p, the bug of SGLang PR #35798), or a dish that p rules out kept on the coin 0. |
| `residual` | 1 | yes, new inputs on every run | A residual that is not max(0, p − q) for every dish: a subtraction that wraps below 0, the lists the wrong way round, an excess written one place off, or a dish whose excess is lost. |
| `pick` | 2 | yes, new inputs on every run | A walk over the weights that picks a dish more or less often than its weight: a comparison that is off by one, a dish of weight 0 picked on the draw 0, or the last dish short. |
| `round` | 3 | yes, new inputs on every run | A round that does not stop at the first send-back, re-plates from p or from q and not from the residual, shifts the dish it picks by one, loses the bonus or draws it from the wrong distribution, or keeps a plate that p rules out after looking ahead. |
| `exact` | 4 | yes, new inputs on every run | Everything the four above miss: over 20,000 rounds [estimated] on each of two seeds, the first token that goes out must follow p, which a chi-square test checks at α = 1e-4 [estimated]. |

## What the site does with your module

1. **Load.** The file is hashed (SHA-256) and compiled in a worker. A module that imports anything, has no `ks_invoke` or speaks another ABI than 2 is refused, with the reason.
2. **Check.** Each check runs in a fresh instance of your module, and a seeded check on a seed drawn when you drop the file. A check may spend 2 s [estimated] in your module. One that spends it ends in `timeout`, and the next check runs.
3. **Record.** A run that ran every check on fresh seeds is written to your ledger on this device, with the module's SHA-256, the seeds and each check's status. A replay of seeds you have seen, and a run that skipped a check, are not.

A `todo!()` left in your code traps the call that reaches it. The site says "not implemented yet" with the panic's words, and the other checks still run. `cargo test` asks the same questions as the site, in Rust, so green here is the time to drop the module there. Only the site's run earns credit.

## Working with a coding agent

`AGENTS.md` and `.claude/` turn Claude Code into a tutor for this lab. It asks for the failing check, its invariant and your hypothesis before it hints, and a guard stops it from editing `rejection-sampler/src/verify.rs` and `rejection-sampler/src/lib.rs`. Another agent that reads `AGENTS.md` gets the rules and not the guard. It is friction, not DRM: `ES_SOLO=0` in your shell turns the guard off, and that is your call.

## Don't lose your work

On day one, in this folder:

```sh
git init && git add -A && git commit -m "rejection-sampler: template"
```

Then commit as the checks go green. That history is your portfolio artifact, and a private remote keeps it safe.
