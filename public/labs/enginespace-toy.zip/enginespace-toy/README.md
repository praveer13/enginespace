# The Rotation

enginespace forge lab `toy`. The forge's practice lab. Keep a rotation of pans: touch a pan to keep it, and when the reach-in is full the next new pan dumps the one that nobody has touched for the longest. In the engine's words: an LRU free queue.

Real Rust, on your machine, with no server. You edit one file, prove it with `cargo test`, build it to WebAssembly and drop the `.wasm` on the lab's page on the enginespace site (`/labs/toy`). The page runs your module in your browser against the site's own checks and records the run on your device. Your code is never uploaded.

## What is in this folder

| Path | What |
|---|---|
| `toy/src/rotation.rs` | **Yours.** The only file marked `TODO(you)`. |
| `toy/src/lib.rs` | The harness (DO NOT EDIT): the crate's own checks, and `ks_invoke`, the bridge the site drives. Reading it is allowed, and the header says which check catches which mistake. |
| `toy/tests/` | The crate's tests, which run those checks. |
| `kit/` | kslab, the small crate that gives your module its ABI: no dependencies and no imports. |
| `rust-toolchain.toml`, `Cargo.lock` | The compiler the checks were written against (Rust 1.96.0, with the wasm32 target) and the lockfile. |
| `AGENTS.md`, `CLAUDE.md`, `.claude/` | Rules and a guard for a coding agent (below). |
| `NOTICE` | Whose code `kit/` and the guard are. |

## The loop

1. Read `toy/src/rotation.rs`, then the header of `toy/src/lib.rs`.
2. `cargo test`, until every check is green. It starts red, because the file you edit holds `todo!()`.
3. `cargo build --release --target wasm32-unknown-unknown`
4. Drop `target/wasm32-unknown-unknown/release/toy.wasm` on the lab's page.

The first time you run cargo here, rustup reads `rust-toolchain.toml` and fetches the compiler and the wasm32 target (`rustup toolchain install` does it by hand). No rustup yet? It is at <https://rustup.rs>. The archive's root is a Cargo workspace, so cargo writes `target/` here, one folder above the crate.

## The checks

| Check | Stage | Seeded | What it catches |
|---|---|---|---|
| `fill` | 1 | no | A rotation that cannot hold what it was sized for, or loses the order the keys came in. |
| `hits` | 1 | no | A touch of a held key that is not a hit, that leaves the key where it was, or that brings in a second copy. |
| `dump` | 2 | no | A full rotation that dumps the wrong key, dumps none, or does not make room. |
| `recency` | 3 | no | A rotation that dumps by arrival, first in and first out, and not by the last touch. |
| `churn` | 4 | yes, new inputs on every run | Everything the four above miss: a seeded run of touches, with the count and the whole order asked every few touches. |

## What the site does with your module

1. **Load.** The file is hashed (SHA-256) and compiled in a worker. A module that imports anything, has no `ks_invoke` or speaks another ABI than 2 is refused, with the reason.
2. **Check.** Each check runs in a fresh instance of your module, and a seeded check on a seed drawn when you drop the file. A check may spend 2 s [estimated] in your module. One that spends it ends in `timeout`, and the next check runs.
3. **Record.** A run that ran every check on fresh seeds is written to your ledger on this device, with the module's SHA-256, the seeds and each check's status. A replay of seeds you have seen, and a run that skipped a check, are not.

A `todo!()` left in your code traps the call that reaches it. The site says "not implemented yet" with the panic's words, and the other checks still run. `cargo test` asks the same questions as the site, in Rust, so green here is the time to drop the module there. Only the site's run earns credit.

## Working with a coding agent

`AGENTS.md` and `.claude/` turn Claude Code into a tutor for this lab. It asks for the failing check, its invariant and your hypothesis before it hints, and a guard stops it from editing `toy/src/rotation.rs` and `toy/src/lib.rs`. Another agent that reads `AGENTS.md` gets the rules and not the guard. It is friction, not DRM: `ES_SOLO=0` in your shell turns the guard off, and that is your call.

## Don't lose your work

On day one, in this folder:

```sh
git init && git add -A && git commit -m "toy: template"
```

Then commit as the checks go green. That history is your portfolio artifact, and a private remote keeps it safe.
