# The Reach-In Manager

enginespace forge lab `hybrid-kv`. Run the reach-in for a line of several stations: one set of hotel pans serves every station's code and every recipe kit, and a ticket fires only when its pans and its kit are all in. Hang and pull tickets, dump the oldest pan, find the shared mise that every station still holds, and call every pan in and out. In the engine's words: a hybrid KV cache manager over one page pool, with LoRA adapters in the same pool (vLLM's hybrid manager, and S-LoRA's unified paging).

Real Rust, on your machine, with no server. You edit one file, prove it with `cargo test`, build it to WebAssembly and drop the `.wasm` on the lab's page on the enginespace site (`/labs/hybrid-kv`). The page runs your module in your browser against the site's own checks and records the run on your device. Your code is never uploaded.

## What is in this folder

| Path | What |
|---|---|
| `hybrid-kv/src/manager.rs` | **Yours.** The only file marked `TODO(you)`. |
| `hybrid-kv/src/lib.rs` | The harness (DO NOT EDIT): the crate's own checks, and `ks_invoke`, the bridge the site drives. Reading it is allowed, and the header says which check catches which mistake. |
| `hybrid-kv/tests/` | The crate's tests, which run those checks. |
| `kit/` | kslab, the small crate that gives your module its ABI: no dependencies and no imports. |
| `rust-toolchain.toml`, `Cargo.lock` | The compiler the checks were written against (Rust 1.96.0, with the wasm32 target) and the lockfile. |
| `AGENTS.md`, `CLAUDE.md`, `.claude/` | Rules and a guard for a coding agent (below). |
| `NOTICE` | Whose code `kit/` and the guard are. |

## The loop

1. Read `hybrid-kv/src/manager.rs`, then the header of `hybrid-kv/src/lib.rs`.
2. `cargo test`, until every check is green. It starts red, because the file you edit holds `todo!()`.
3. `cargo build --release --target wasm32-unknown-unknown`
4. Drop `target/wasm32-unknown-unknown/release/hybrid_kv.wasm` on the lab's page.

The first time you run cargo here, rustup reads `rust-toolchain.toml` and fetches the compiler and the wasm32 target (`rustup toolchain install` does it by hand). No rustup yet? It is at <https://rustup.rs>. The archive's root is a Cargo workspace, so cargo writes `target/` here, one folder above the crate.

## The checks

| Check | Stage | Seeded | What it catches |
|---|---|---|---|
| `one_group` | 1 | yes, new inputs on every run | A page count that is not the ceiling of the tokens over the block, an admit that is not all or nothing, a free that leaks a page or sends pages back in the wrong order, a shared block that the first request to finish gives back, and a block published twice. |
| `sliding` | 2 | yes, new inputs on every run | A window that keeps one token too many or lets go of a block the next token still reads, an append that does not count the pages its windows give back, and an admit that takes the pages of the groups it can cover before it finds the pool short. |
| `state` | 3 | yes, new inputs on every run | A state group that keeps every block of a long request, or lets go of the block that holds the state at the edge, or counts its pages like an attention group. |
| `hit_all_groups` | 4 | yes, new inputs on every run | A prefix hit that is the longest of any one group, the union, in place of the longest that every group holds, or one that covers the last token of the prompt or ends inside a block. |
| `adapter_pages` | 5 | yes, new inputs on every run | An adapter that is charged more or fewer pages than it asked for, one that is unloaded while a request runs on it, an admit with an adapter that is not resident, and a block that is shared between the base model and an adapter. |
| `gauntlet` | 6 | yes, new inputs on every run | Everything the five above miss: page conservation, reference counts, block tables per group rule, the cache and the free queue, adapters and their users, and every block published exactly once, checked after each of about 2,000 operations on four pools, and a reset that is accepted while a request runs. |

## What the site does with your module

1. **Load.** The file is hashed (SHA-256) and compiled in a worker. A module that imports anything, has no `ks_invoke` or speaks another ABI than 2 is refused, with the reason.
2. **Check.** Each check runs in a fresh instance of your module, and a seeded check on a seed drawn when you drop the file. A check may spend 2 s [estimated] in your module. One that spends it ends in `timeout`, and the next check runs.
3. **Record.** A run that ran every check on fresh seeds is written to your ledger on this device, with the module's SHA-256, the seeds and each check's status. A replay of seeds you have seen, and a run that skipped a check, are not.

A `todo!()` left in your code traps the call that reaches it. The site says "not implemented yet" with the panic's words, and the other checks still run. `cargo test` asks the same questions as the site, in Rust, so green here is the time to drop the module there. Only the site's run earns credit.

## Working with a coding agent

`AGENTS.md` and `.claude/` turn Claude Code into a tutor for this lab. It asks for the failing check, its invariant and your hypothesis before it hints, and a guard stops it from editing `hybrid-kv/src/manager.rs` and `hybrid-kv/src/lib.rs`. Another agent that reads `AGENTS.md` gets the rules and not the guard. It is friction, not DRM: `ES_SOLO=0` in your shell turns the guard off, and that is your call.

## Don't lose your work

On day one, in this folder:

```sh
git init && git add -A && git commit -m "hybrid-kv: template"
```

Then commit as the checks go green. That history is your portfolio artifact, and a private remote keeps it safe.
