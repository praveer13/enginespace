# enginespace GPU kit 0.1.0

The local half of the Engine Internals GPU labs (ARCHITECTURE section 9). This folder holds the grader, one locked environment for each engine, and what a lab needs beside them. It is one folder, and it runs from wherever you unzip it.

| Folder | Holds |
|---|---|
| `grader/` | the `enginespace` command, as a uv project (the grader 0.1.0, source hash `3893f64686e4f60542ddcf0644ab99da9f4e0f56f33c5feb1ed977f96b12a875`) |
| `envs/` | one locked uv project for each engine, each with a hashed `requirements.txt` and a `Dockerfile`; `envs/README.md` says which engine runs which lab |
| `references/` | `manifest.json`, the pinned list of large files that `enginespace fetch <lab>` downloads |
| `course.lock.json` | the engine pins that `enginespace doctor` compares your environment with |
| `runners/` | the copy-and-paste sessions for rented GPUs |

## Check what you downloaded

The course site lists this file's size and SHA-256 in `labs/manifest.json`. Compare them before you unpack it:

```sh
sha256sum enginespace-gpu-kit-0.1.0.zip
```

## Install with uv 0.10.2

```sh
unzip enginespace-gpu-kit-0.1.0.zip && cd enginespace-gpu-kit
uv sync --locked --project envs/vllm
uv run --project envs/vllm enginespace doctor
uv run --project envs/vllm enginespace version
```

`enginespace version` prints the grader's source hash. It has to be the one in the table above, and the course site only credits a receipt from a grader build it published.

## Install with pip

Use Python 3.12 in a virtual environment:

```sh
pip install --require-hashes -r envs/vllm/requirements.txt
pip install --no-deps ./grader
```

## Rent a GPU

Each environment has a `Dockerfile`. Build it from this folder: `docker build -f envs/vllm/Dockerfile -t enginespace-vllm .`. Nobody has built these images yet [unverified], and the owner's first runs will say.

## What this kit does not do

It sends nothing anywhere. A receipt is a file that you drop on the course site's receipts page, and only `enginespace fetch` downloads, from the pinned addresses of `references/manifest.json`.
